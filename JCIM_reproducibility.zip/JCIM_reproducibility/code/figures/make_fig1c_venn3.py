#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Regenerate Figure 1C: 3-set Venn (CD training x MDD-with-GAD x MDD-without-GAD)
Documented thresholds (reproducible from E:\\IBD\\cd):
  CD (GSE94648):        (P < 0.01 | adj.P < 0.2) & |logFC| > 0.3
  MDD_GAD (GSE98793):   (P < 0.01 | adj.P < 0.2) & |logFC| > 0.2
  MDD_noGAD (GSE98793): (P < 0.01 | adj.P < 0.2) & |logFC| > 0.2
9 direction-consistent candidates are annotated (Table 1).
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib_venn import venn3
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"
os.makedirs(OUT, exist_ok=True)

cd = pd.read_csv(os.path.join(SRC, "DEG_CD_full.csv"))
gad = pd.read_csv(os.path.join(SRC, "DEG_MDD_full.csv"))
nogad = pd.read_csv(os.path.join(SRC, "DEG_MDD_noGAD_full.csv"))

cd_m = ((cd["P.Value"] < 0.01) | (cd["adj.P.Val"] < 0.2)) & (cd["logFC"].abs() > 0.3)
up_cd = set(cd[cd_m & (cd.logFC > 0)].Gene); down_cd = set(cd[cd_m & (cd.logFC < 0)].Gene)

def mdd_sets(d):
    m = ((d["P.Value"] < 0.01) | (d["adj.P.Val"] < 0.2)) & (d["logFC"].abs() > 0.2)
    return set(d[m & (d.logFC > 0)].Gene), set(d[m & (d.logFC < 0)].Gene)

up_gad, down_gad = mdd_sets(gad)
up_nogad, down_nogad = mdd_sets(nogad)

cd_all = up_cd | down_cd
gad_all = up_gad | down_gad
nogad_all = up_nogad | down_nogad

# region counts (venn3 subset order: 100=CD only, 010=GAD only, 110=CD&GAD, 001=noGAD only, 101=CD&noGAD, 011=GAD&noGAD, 111=all)
only_cd   = cd_all - gad_all - nogad_all
only_gad  = gad_all - cd_all - nogad_all
only_nog  = nogad_all - cd_all - gad_all
cd_gad    = (cd_all & gad_all) - nogad_all
cd_nog    = (cd_all & nogad_all) - gad_all
gad_nog   = (gad_all & nogad_all) - cd_all
triple    = cd_all & gad_all & nogad_all
subsets = (len(only_cd), len(only_gad), len(cd_gad), len(only_nog), len(cd_nog), len(gad_nog), len(triple))
print("subsets (100,010,110,001,101,011,111):", subsets)

cand = sorted(pd.read_csv(os.path.join(SRC, "Candidate_Genes_v2.csv"))["Candidate_Gene"])
print("9 candidates:", cand)

cand_in = {g: [] for g in cand}
for g in cand:
    if g in cd_all: cand_in[g].append("CD")
    if g in gad_all: cand_in[g].append("MDD+GAD")
    if g in nogad_all: cand_in[g].append("MDD−GAD")
for g in cand:
    print("  %-9s -> %s" % (g, " + ".join(cand_in[g])))

# ------------- plot -------------
fig, ax = plt.subplots(figsize=(9.2, 6.6))
v = venn3(subsets=subsets, set_labels=(
    "CD training\n(GSE94648, n=%d)" % len(cd_all),
    "MDD with GAD\n(GSE98793, n=%d)" % len(gad_all),
    "MDD without GAD\n(GSE98793, n=%d)" % len(nogad_all)),
    set_colors=("#E53935", "#1E88E5", "#7CB342"), alpha=0.45, ax=ax)

for lab in ["100", "010", "110", "001", "101", "011", "111"]:
    lbl = v.get_label_by_id(lab)
    if lbl is not None:
        lbl.set_fontsize(13)
        lbl.set_fontweight("bold")

for t in v.set_labels:
    if t is not None:
        t.set_fontsize(11)
        t.set_fontweight("bold")

ax.set_title("Figure 1C. Venn diagram of DEG overlaps across CD and MDD subgroups",
             fontsize=12.5, fontweight="bold", pad=12)

# candidate annotation box
up_genes = ["MMP8", "TDRD9", "CRISP3", "GRB10", "S100A12", "TNNT1"]
down_genes = ["BCL11A", "COBLL1", "MS4A1"]
box_text = ("9 direction-consistent candidate DEGs (Table 1)\n"
            "Up-regulated: " + ", ".join(up_genes) + "\n"
            "Down-regulated: " + ", ".join(down_genes))
ax.annotate(box_text, xy=(0.5, -0.14), xycoords="axes fraction", ha="center", va="top",
            fontsize=9.5, bbox=dict(boxstyle="round,pad=0.45", fc="#fdf6ec", ec="#d9a94e", lw=1.2))

plt.tight_layout()
for ext in ["png", "pdf", "tif"]:
    p = os.path.join(OUT, "Figure_1C_updated.%s" % ext)
    fig.savefig(p, dpi=300, bbox_inches="tight")
    print("Saved:", p)
plt.close(fig)

with open(os.path.join(SRC, "venn3_final_counts.txt"), "w") as f:
    f.write("CD_all=%d GAD_all=%d noGAD_all=%d\n" % (len(cd_all), len(gad_all), len(nogad_all)))
    f.write("regions 100=%d 010=%d 110=%d 001=%d 101=%d 011=%d 111=%d\n" % subsets)
    for g in cand:
        f.write("%s: %s\n" % (g, " + ".join(cand_in[g])))
print("counts written to venn3_final_counts.txt")
