#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Figure 2 (revised): MMP8 validation across four independent cohorts.
(A) CD training (GSE94648) boxplot       (D) MDD validation (GSE76826) boxplot
(B) CD validation (GSE169568, 82-sample) (E) ROC MMP8 CD training
(C) MDD training (GSE98793, with GAD)    (F) ROC MMP8 MDD training
Panel B uses the unified 82-sample design (30 HC + 52 CD): MW p=0.099, AUC=0.610.
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_curve, auc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.linewidth": 0.8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "in", "ytick.direction": "in",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.3,
})

def load_expr(f):
    df = pd.read_csv(f, index_col=0)
    return df.T if df.shape[1] > df.shape[0] else df

def load_groups(f):
    with open(f) as fh:
        return [l.strip() for l in fh.readlines() if l.strip()]

expr_cd = load_expr(os.path.join(SRC, "Exprs_CD_key.csv"))
expr_mdd = load_expr(os.path.join(SRC, "Exprs_MDD_key.csv"))
expr_mdd_val = load_expr(os.path.join(SRC, "Exprs_MDD_val_key.csv"))
e147 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key_fixed.csv"), index_col=0)
e82 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key.csv"), index_col=0)
ids82 = e82.columns.tolist()

g_cd = load_groups(os.path.join(SRC, "Groups_CD.txt"))
g_val = load_groups(os.path.join(SRC, "Groups_CD_val.txt"))
g_mdd = load_groups(os.path.join(SRC, "Groups_MDD.txt"))
g_mdd_val = load_groups(os.path.join(SRC, "Groups_MDD_val.txt"))

BOXCOL = {"Control": "#4CAF50", "Active_CD": "#E53935", "CD": "#E53935",
          "MDD": "#1E88E5", "MDD_with_GAD": "#1E88E5"}

def boxplot(ax, exprs, groups, gene, include, title, colors=None):
    colors = colors or BOXCOL
    vals = exprs[gene].values[:len(groups)]
    dfp = pd.DataFrame({"Expression": vals, "Group": groups[:len(vals)]}).dropna()
    dfp = dfp[dfp.Group.isin(include)]
    order = sorted(dfp.Group.unique(), key=lambda x: include.index(x) if x in include else 99)
    data = [dfp[dfp.Group == g]["Expression"].values for g in order]
    bp = ax.boxplot(data, positions=range(len(order)), widths=0.5, patch_artist=True, showfliers=False)
    for patch, g in zip(bp["boxes"], order):
        patch.set_facecolor(colors.get(g, "#999999")); patch.set_alpha(0.7)
        patch.set_edgecolor("black"); patch.set_linewidth(0.6)
    for w in bp["whiskers"]: w.set_color("black"); w.set_lw(0.6)
    for c in bp["caps"]: c.set_color("black"); c.set_lw(0.6)
    for m in bp["medians"]: m.set_color("black"); m.set_lw(0.8)
    for i, g in enumerate(order):
        y = dfp[dfp.Group == g]["Expression"].values
        ax.scatter(np.full(len(y), i) + np.random.normal(0, 0.04, len(y)), y, s=6,
                   color=colors.get(g, "#999999"), alpha=0.4, edgecolors="none", rasterized=True)
    if len(order) >= 2:
        u, p = stats.mannwhitneyu(data[1], data[0], alternative="two-sided")
        pstr = ("p = %.3f" % p) if p >= 0.001 else ("p < 0.001" if False else "p = %.2e" % p)
        ax.text(0.5, 0.95, "Mann\u2013Whitney " + pstr, transform=ax.transAxes,
                fontsize=7, ha="center", va="top", style="italic")
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels(order, fontsize=7)
    ax.set_ylabel("Normalized expression", fontsize=7)
    ax.set_title(title, fontsize=8, fontweight="bold", pad=5)

def roc(ax, exprs, groups, gene, title, color, y_true=None):
    vals = exprs[gene].values[:len(groups)]
    if y_true is None:
        y_true = np.array([1 if g != "Control" else 0 for g in groups[:len(vals)]])
    fpr, tpr, _ = roc_curve(y_true, vals)
    roc_auc = auc(fpr, tpr)
    boot = []
    rng = np.random.RandomState(42)
    for _ in range(2000):
        idx = rng.choice(len(y_true), len(y_true), replace=True)
        if len(np.unique(y_true[idx])) < 2:
            continue
        boot.append(auc(*roc_curve(y_true[idx], vals[idx])[:2]))
    lo, hi = np.percentile(boot, [2.5, 97.5])
    ax.plot(fpr, tpr, color=color, lw=1.5, label="AUC = %.3f (95%% CI %.3f\u2013%.3f)" % (roc_auc, lo, hi))
    ax.plot([0, 1], [0, 1], "k--", lw=0.6, alpha=0.5)
    ax.set_xlabel("1 \u2212 Specificity", fontsize=7)
    ax.set_ylabel("Sensitivity", fontsize=7)
    ax.set_title(title, fontsize=8, fontweight="bold", pad=5)
    ax.legend(fontsize=6.5, loc="lower right", frameon=True, edgecolor="grey")
    ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
    print("  ROC %s: AUC %.3f (%.3f-%.3f)" % (title[:30], roc_auc, lo, hi))

mmp8_val = e147.loc["MMP8", ids82].astype(float).values

fig, axes = plt.subplots(2, 3, figsize=(16, 9.5))
boxplot(axes[0, 0], expr_cd, g_cd, "MMP8", ["Control", "Active_CD"],
        "A: MMP8 \u2014 CD Training (GSE94648)")
boxplot(axes[0, 1], pd.DataFrame({"MMP8": mmp8_val}), g_val, "MMP8", ["Control", "CD"],
        "B: MMP8 \u2014 CD Validation (GSE169568; 30 HC, 52 CD)")
boxplot(axes[0, 2], expr_mdd, g_mdd, "MMP8", ["Control", "MDD_with_GAD"],
        "C: MMP8 \u2014 MDD Training (GSE98793)")
boxplot(axes[1, 0], expr_mdd_val, g_mdd_val, "MMP8", ["Control", "MDD"],
        "D: MMP8 \u2014 MDD Validation (GSE76826)")
roc(axes[1, 1], expr_cd, g_cd, "MMP8", "E: MMP8 ROC \u2014 CD Training", "#E53935")
roc(axes[1, 2], expr_mdd, g_mdd, "MMP8", "F: MMP8 ROC \u2014 MDD Training", "#1E88E5")

plt.tight_layout(pad=1.6)
for ext in ["pdf", "png"]:
    p = os.path.join(OUT, "Figure_2_updated.%s" % ext)
    fig.savefig(p, dpi=300)
    print("Saved:", p)
plt.close(fig)
from PIL import Image
im = Image.open(os.path.join(OUT, "Figure_2_updated.png"))
im.save(os.path.join(OUT, "Figure_2_updated.tif"), compression="tiff_lzw")
print("Saved: Figure_2_updated.tif (LZW)")