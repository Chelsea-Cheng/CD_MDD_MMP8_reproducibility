#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fig 2B: MMP8 CD-validation box + ROC from recovered IDAT probe ILMN_1736026.
Inputs are verified ground-truth files in E:\IBD\cd."""
import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"
os.makedirs(OUT, exist_ok=True)

expr = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key_fixed.csv"), index_col=0)
groups = pd.read_csv(os.path.join(SRC, "Groups_CD_val_fixed.txt"), header=None,
                     names=["group"])
groups["group"] = groups["group"].str.strip()
sample_ids = list(expr.columns)
assert len(sample_ids) == len(groups), f"col {len(sample_ids)} vs group {len(groups)}"
g = groups["group"].values
mmp8 = expr.loc["MMP8"].values.astype(float)

ctrl = mmp8[g == "Control"]
cdv = mmp8[g == "CD"]
print(f"n={len(mmp8)} (Control={len(ctrl)}, CD={len(cdv)})")
print(f"mean Control={ctrl.mean():.3f}, mean CD={cdv.mean():.3f}  (CD higher? {cdv.mean()>ctrl.mean()})")

u, p_mw = stats.mannwhitneyu(cdv, ctrl, alternative="two-sided")
y = (g == "CD").astype(int)
auc = roc_auc_score(y, mmp8)
rng = np.random.default_rng(42)
boot = [roc_auc_score(y[idx], mmp8[idx]) for idx in
        (rng.integers(0, len(y), len(y)) for _ in range(2000))
        if len(np.unique(y[idx])) == 2]
ci_low, ci_high = np.percentile(boot, [2.5, 97.5])
print(f"Mann-Whitney p = {p_mw:.3e}; AUC = {auc:.3f} (95% CI {ci_low:.3f}-{ci_high:.3f})")

fpr, tpr, _ = roc_curve(y, mmp8)
fig, axes = plt.subplots(2, 1, figsize=(5.2, 8.4))
fig.suptitle("Figure 2B. MMP8 in CD validation cohort", fontsize=12, fontweight="bold", y=0.98)

ax0 = axes[0]
bp = ax0.boxplot([ctrl, cdv], positions=[1, 2], widths=0.5, patch_artist=True,
                 showfliers=False, medianprops=dict(color="black"))
for patch, c in zip(bp["boxes"], ["#7fb3d5", "#e74c3c"]):
    patch.set_facecolor(c); patch.set_alpha(0.75)
for i, (vals, c) in enumerate(zip([ctrl, cdv], ["#7fb3d5", "#e74c3c"]), start=1):
    x = np.random.normal(i, 0.06, len(vals))
    ax0.scatter(x, vals, s=14, color=c, alpha=0.6, edgecolor="white", linewidth=0.4)
ax0.set_xticks([1, 2])
ax0.set_xticklabels([f"Control\n(n={len(ctrl)})", f"CD\n(n={len(cdv)})"], fontsize=10)
ax0.set_ylabel("MMP8 expression (log2)", fontsize=10)
ax0.set_title("Upper: MMP8 expression by group", fontsize=10.5, loc="left")
ax0.text(0.02, 0.96, f"Mann-Whitney p = {p_mw:.1e}", transform=ax0.transAxes,
         fontsize=9.5, va="top", fontweight="bold")
ax0.grid(axis="y", alpha=0.3)

ax1 = axes[1]
ax1.plot(fpr, tpr, color="#2c3e50", lw=2.2, label=f"MMP8 (AUC = {auc:.3f})")
ax1.plot([0, 1], [0, 1], "--", color="gray", lw=1)
ax1.set_xlabel("1 - Specificity", fontsize=10)
ax1.set_ylabel("Sensitivity", fontsize=10)
ax1.set_title(f"Lower: ROC (95% CI {ci_low:.2f}-{ci_high:.2f})", fontsize=10.5, loc="left")
ax1.legend(loc="lower right", fontsize=9)
ax1.grid(alpha=0.3)

plt.tight_layout(rect=[0, 0, 1, 0.96])
base = os.path.join(OUT, "Figure_2B_updated")
fig.savefig(base + ".png", dpi=300, bbox_inches="tight")
fig.savefig(base + ".pdf", bbox_inches="tight")
try:
    fig.savefig(base + ".tif", dpi=300, bbox_inches="tight")
    print("TIFF saved")
except Exception as e:
    print("TIFF skip:", e)
plt.close(fig)
print("Saved Fig 2B ->", base + ".png")
