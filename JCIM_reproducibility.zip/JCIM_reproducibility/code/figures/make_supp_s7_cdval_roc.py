#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Supplementary Figure S7: MMP8 ROC in the CD validation cohort (GSE169568,
unified 82-sample design; 30 healthy controls, 52 CD patients).
AUC = 0.610 (95% CI 0.484-0.735), matching the manuscript text.
Times New Roman fonts.
"""
import os
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, auc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.linewidth": 0.8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "in", "ytick.direction": "in",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.3,
})

e147 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key_fixed.csv"), index_col=0)
e82 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key.csv"), index_col=0)
ids82 = e82.columns.tolist()
g82 = pd.read_csv(os.path.join(SRC, "Groups_CD_val.txt"), header=None)[0].tolist()
mmp8 = e147.loc["MMP8", ids82].astype(float).values
y = np.array([1 if str(g).strip() != "Control" else 0 for g in g82])

fpr, tpr, _ = roc_curve(y, mmp8)
roc_auc = auc(fpr, tpr)
rng = np.random.default_rng(42)
boot = []
for _ in range(2000):
    idx = rng.integers(0, len(y), len(y))
    if len(np.unique(y[idx])) < 2:
        continue
    boot.append(auc(*roc_curve(y[idx], mmp8[idx])[:2]))
lo, hi = np.percentile(boot, [2.5, 97.5])
print("AUC = %.3f (95%% CI %.3f-%.3f)" % (roc_auc, lo, hi))

fig, ax = plt.subplots(figsize=(4.6, 4.2))
ax.plot(fpr, tpr, color="#E53935", lw=2.0,
        label="AUC = %.3f (95%% CI %.3f\u2013%.3f)" % (roc_auc, lo, hi))
ax.plot([0, 1], [0, 1], "k--", lw=0.6, alpha=0.5)
ax.set_xlabel("1 \u2212 Specificity", fontsize=9)
ax.set_ylabel("Sensitivity", fontsize=9)
ax.legend(fontsize=9, loc="lower right", frameon=True, edgecolor="grey")
ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
ax.set_title("MMP8 ROC \u2014 CD Validation (GSE169568; n = 82)",
             fontsize=9.5, fontweight="bold", pad=6)
plt.tight_layout()
for ext in ["pdf", "png"]:
    p = os.path.join(OUT, "Supplementary_Figure_S7_CD_val_ROC.%s" % ext)
    fig.savefig(p, dpi=300)
    print("Saved:", p)
plt.close(fig)
from PIL import Image
im = Image.open(os.path.join(OUT, "Supplementary_Figure_S7_CD_val_ROC.png"))
im.save(os.path.join(OUT, "Supplementary_Figure_S7_CD_val_ROC.tif"), compression="tiff_lzw")
print("Saved: Supplementary_Figure_S7_CD_val_ROC.tif (LZW)")