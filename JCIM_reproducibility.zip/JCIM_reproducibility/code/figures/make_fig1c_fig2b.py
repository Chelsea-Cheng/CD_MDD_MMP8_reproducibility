#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Regenerate Fig 1C (Venn: 9 shared candidate DEGs) and Fig 2B (MMP8 CD-validation
box + ROC from recovered IDAT probe ILMN_1736026).
All inputs are the verified ground-truth files in E:\IBD\cd.
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib_venn import venn2
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------
# 1) Verify Venn sets from raw DEG files
# ----------------------------------------------------------------------------
cd = pd.read_csv(os.path.join(SRC, "DEG_CD_full.csv"))
mdd = pd.read_csv(os.path.join(SRC, "DEG_MDD_full.csv"))

# CD training DEGs: |logFC| > 0.5 and raw P < 0.01
cd_deg = cd[(cd["logFC"].abs() > 0.5) & (cd["P.Value"] < 0.01)].copy()
# MDD training DEGs: top 200 transcripts by raw P-value
mdd_deg = mdd.sort_values("P.Value").head(200).copy()

cd_genes = set(cd_deg["Gene"])
mdd_genes = set(mdd_deg["Gene"])
shared = sorted(cd_genes & mdd_genes)

print("CD DEG count (|logFC|>0.5 & P<0.01):", len(cd_genes))
print("MDD DEG count (top 200 by P):", len(mdd_genes))
print("Shared overlap count:", len(shared))
print("Shared genes:", shared)

# Expected 9 from Candidate_Genes_v2.csv
cand = pd.read_csv(os.path.join(SRC, "Candidate_Genes_v2.csv"))
cand_genes = set(cand["Candidate_Gene"])
print("Candidate_Genes_v2 (9):", sorted(cand_genes))
print("Overlap matches candidate list exactly:", set(shared) == cand_genes)

# Direction of the 9 shared genes in CD training
shared_dir = []
for g in shared:
    row = cd_deg[cd_deg["Gene"] == g]
    if len(row):
        fc = row["logFC"].iloc[0]
        shared_dir.append((g, "up" if fc > 0 else "down", round(fc, 3)))
print("Shared gene directions in CD training:", shared_dir)
n_up = sum(1 for _, d, _ in shared_dir if d == "up")
n_down = sum(1 for _, d, _ in shared_dir if d == "down")
print(f"Among 9 shared: {n_up} up, {n_down} down")

# ----------------------------------------------------------------------------
# Fig 1C : Venn diagram
# ----------------------------------------------------------------------------
cd_only = len(cd_genes - mdd_genes)
mdd_only = len(mdd_genes - cd_genes)
both = len(shared)

fig, ax = plt.subplots(figsize=(7.2, 5.6))
v = venn2(subsets=(cd_only, mdd_only, both), set_labels=(
    f"CD training DEGs\n(GSE94648, n={len(cd_genes)})",
    f"MDD training DEGs\n(GSE98793, n={len(mdd_genes)})"), ax=ax)
# style
for lab in ["10", "01", "11"]:
    if v.get_label_by_id(lab):
        v.get_label_by_id(lab).set_fontsize(15)
        v.get_label_by_id(lab).set_fontweight("bold")
for text in v.set_labels:
    if text:
        text.set_fontsize(11)
        text.set_fontweight("bold")
ax.set_title("Figure 1C. Venn diagram of 9 shared candidate DEGs", fontsize=12,
             fontweight="bold", pad=12)
# gene list as annotation
gene_lines = "\n".join([", ".join(shared[i:i+3]) for i in range(0, len(shared), 3)])
ax.annotate(f"9 shared candidate DEGs:\n{gene_lines}",
            xy=(0.5, -0.18), xycoords="axes fraction", ha="center", va="top",
            fontsize=9.5, bbox=dict(boxstyle="round,pad=0.4", fc="#eef3fb",
                                    ec="#9bb4d8", lw=1))
plt.tight_layout()
p1 = os.path.join(OUT, "Figure_1C_updated.png")
fig.savefig(p1, dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "Figure_1C_updated.pdf"), bbox_inches="tight")
plt.close(fig)
print("Saved Fig 1C ->", p1)

# ----------------------------------------------------------------------------
# 2) Fig 2B : MMP8 CD-validation (recovered IDAT probe)
# ----------------------------------------------------------------------------
expr = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key_fixed.csv"), index_col=0)
groups = pd.read_csv(os.path.join(SRC, "Groups_CD_val_fixed.txt"), header=None,
                     names=["group"])
groups["group"] = groups["group"].str.strip()
# align by column order
sample_ids = list(expr.columns)
assert len(sample_ids) == len(groups), f"col {len(sample_ids)} vs group {len(groups)}"
g = groups["group"].values
mmp8 = expr.loc["MMP8"].values.astype(float)

ctrl_mask = (g == "Control")
cd_mask = (g == "CD")
ctrl_vals = mmp8[ctrl_mask]
cd_vals = mmp8[cd_mask]
print(f"\nFig 2B MMP8 CD-validation: n={len(mmp8)} (Control={ctrl_vals.size}, CD={cd_vals.size})")

# Mann-Whitney
u, p_mw = stats.mannwhitneyu(cd_vals, ctrl_vals, alternative="two-sided")
# AUC
y = (g == "CD").astype(int)
auc = roc_auc_score(y, mmp8)
# 95% CI via 2000 stratified bootstrap
rng = np.random.default_rng(42)
boot = []
for _ in range(2000):
    idx = rng.integers(0, len(y), len(y))
    if len(np.unique(y[idx])) < 2:
        continue
    try:
        boot.append(roc_auc_score(y[idx], mmp8[idx]))
    except Exception:
        pass
ci_low, ci_high = np.percentile(boot, [2.5, 97.5])
print(f"Mann-Whitney p = {p_mw:.2e}; AUC = {auc:.3f} (95% CI {ci_low:.3f}-{ci_high:.3f})")

# Build ROC curve
from sklearn.metrics import roc_curve
fpr, tpr, _ = roc_curve(y, mmp8)

# Plot: two rows (box + ROC)
fig, axes = plt.subplots(2, 1, figsize=(5.2, 8.4))
fig.suptitle("Figure 2B. MMP8 in CD validation cohort", fontsize=12,
             fontweight="bold", y=0.98)

# Box + jittered points
ax0 = axes[0]
data = [ctrl_vals, cd_vals]
bp = ax0.boxplot(data, positions=[1, 2], widths=0.5, patch_artist=True,
                 showfliers=False, medianprops=dict(color="black"))
colors = ["#7fb3d5", "#e74c3c"]
for patch, c in zip(bp["boxes"], colors):
    patch.set_facecolor(c)
    patch.set_alpha(0.75)
for i, (vals, c) in enumerate(zip(data, colors), start=1):
    x = np.random.normal(i, 0.06, len(vals))
    ax0.scatter(x, vals, s=14, color=c, alpha=0.6, edgecolor="white", linewidth=0.4)
ax0.set_xticks([1, 2])
ax0.set_xticklabels([f"Control\n(n={len(ctrl_vals)})", f"CD\n(n={len(cd_vals)})"],
                    fontsize=10)
ax0.set_ylabel("MMP8 expression (log2)", fontsize=10)
ax0.set_title("Upper: MMP8 expression by group", fontsize=10.5, loc="left")
ax0.text(0.02, 0.96, f"Mann–Whitney p = {p_mw:.1e}", transform=ax0.transAxes,
         fontsize=9.5, va="top", fontweight="bold")
ax0.grid(axis="y", alpha=0.3)

# ROC
ax1 = axes[1]
ax1.plot(fpr, tpr, color="#2c3e50", lw=2.2,
         label=f"MMP8 (AUC = {auc:.3f})")
ax1.plot([0, 1], [0, 1], "--", color="gray", lw=1)
ax1.set_xlabel("1 – Specificity", fontsize=10)
ax1.set_ylabel("Sensitivity", fontsize=10)
ax1.set_title(f"Lower: ROC (95% CI {ci_low:.2f}–{ci_high:.2f})", fontsize=10.5,
              loc="left")
ax1.legend(loc="lower right", fontsize=9)
ax1.grid(alpha=0.3)

plt.tight_layout(rect=[0, 0, 1, 0.96])
p2 = os.path.join(OUT, "Figure_2B_updated.png")
fig.savefig(p2, dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "Figure_2B_updated.pdf"), bbox_inches="tight")
plt.close(fig)
print("Saved Fig 2B ->", p2)
print("\nSUMMARY")
print(f"Fig1C: CD={len(cd_genes)}, MDD={len(mdd_genes)}, overlap={both}")
print(f"Fig2B: n={len(mmp8)} (Ctrl {len(ctrl_vals)}/CD {len(cd_vals)}), "
      f"MW p={p_mw:.2e}, AUC={auc:.3f} (95%CI {ci_low:.3f}-{ci_high:.3f})")
