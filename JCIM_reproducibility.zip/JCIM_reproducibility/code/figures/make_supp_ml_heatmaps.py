#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Supplementary figure (replaces former Figure 1D-F panels):
  (A) Machine-learning feature-selection matrix (MMP8 / TDRD9 / BCL11A)
  (B) Candidate-gene heatmap, CD training (GSE94648)
  (C) Candidate-gene heatmap, MDD training (GSE98793)
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.linewidth": 0.8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "in", "ytick.direction": "in",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.3,
})

def load_expr(f):
    df = pd.read_csv(f, index_col=0)
    return df.T if df.shape[1] > df.shape[0] else df

def load_groups(f):
    with open(f) as fh:
        return [l.strip() for l in fh.readlines() if l.strip()]

expr_cd = load_expr(os.path.join(SRC, "CD_train_expr_9genes.csv"))
expr_mdd = load_expr(os.path.join(SRC, "MDD_train_expr_9genes.csv"))
g_cd = load_groups(os.path.join(SRC, "Groups_CD.txt"))
g_mdd = load_groups(os.path.join(SRC, "Groups_MDD.txt"))
cand = pd.read_csv(os.path.join(SRC, "Candidate_Genes_v2.csv"))["Candidate_Gene"].tolist()

fig, axes = plt.subplots(1, 3, figsize=(16, 4.6))

# A: ML selection matrix
ml = {"MMP8": {"SVM-RFE": 1, "LASSO": 0, "Random Forest": 1},
      "TDRD9": {"SVM-RFE": 0, "LASSO": 1, "Random Forest": 1},
      "BCL11A": {"SVM-RFE": 0, "LASSO": 0, "Random Forest": 1}}
genes = list(ml.keys()); methods = ["SVM-RFE", "LASSO", "Random Forest"]
data = np.array([[ml[g][m] for m in methods] for g in genes])
x = np.arange(len(genes)); w = 0.25
for j, (m, c) in enumerate(zip(methods, ["#E53935", "#FB8C00", "#43A047"])):
    axes[0].bar(x + j * w - w, data[:, j], w, label=m, color=c, alpha=0.8,
                edgecolor="black", lw=0.4)
axes[0].set_xticks(x); axes[0].set_xticklabels(genes, fontsize=9, rotation=20, ha="right")
axes[0].set_ylabel("Selected (1) / Not selected (0)", fontsize=7)
axes[0].set_title("A: Machine-learning feature selection", fontsize=9, fontweight="bold", pad=6)
axes[0].set_ylim(0, 1.3); axes[0].set_yticks([0, 1]); axes[0].set_yticklabels(["No", "Yes"], fontsize=7)
axes[0].legend(fontsize=6, frameon=True, edgecolor="grey", loc="upper right")

def heatmap(ax, exprs, groups, title):
    groups = groups[:exprs.shape[1]]
    order_map = []
    seen = set()
    for g in groups:
        if g not in seen:
            order_map.append(g); seen.add(g)
    genes_in = [g for g in cand if g in exprs.columns]
    colidx = sorted(range(exprs.shape[1]),
                    key=lambda i: order_map.index(groups[i]) if groups[i] in order_map else 99)
    mat = exprs.iloc[:, colidx].values.T
    mat_z = (mat - mat.mean(axis=1, keepdims=True)) / (mat.std(axis=1, keepdims=True) + 1e-10)
    im = ax.imshow(mat_z, aspect="auto", cmap="RdBu_r", vmin=-2, vmax=2, interpolation="bilinear")
    ax.set_yticks(range(len(genes_in)))
    ax.set_yticklabels(genes_in, fontsize=6.5)
    ax.set_xticks([])
    ax.set_title(title, fontsize=9, fontweight="bold")
    cbar = plt.colorbar(im, ax=ax, shrink=0.7, pad=0.02)
    cbar.set_label("Z-score", fontsize=6)
    cbar.ax.tick_params(labelsize=5)
    return genes_in

g_cd = [g for g in cand if g in expr_cd.columns]
g_mdd = [g for g in cand if g in expr_mdd.columns]
print("heatmap genes CD:", g_cd)
print("heatmap genes MDD:", g_mdd)
heatmap(axes[1], expr_cd, g_cd, "B: Candidate genes in CD (GSE94648)")
heatmap(axes[2], expr_mdd, g_mdd, "C: Candidate genes in MDD (GSE98793)")

plt.tight_layout(pad=1.4)
for ext in ["pdf", "png"]:
    p = os.path.join(OUT, "Supplementary_Figure_ML_and_Heatmaps.%s" % ext)
    fig.savefig(p, dpi=300)
    print("Saved:", p)
plt.close(fig)