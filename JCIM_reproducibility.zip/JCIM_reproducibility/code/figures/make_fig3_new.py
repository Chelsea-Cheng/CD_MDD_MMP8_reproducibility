#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Figure 3 (revised): ROC curve summary in 2-by-2 panel, Times New Roman.
  (A) MMP8  ROC - CD training  (GSE94648)   expected AUC 0.655 (0.528-0.776)
  (B) MMP8  ROC - MDD training (GSE98793)   expected AUC 0.692 (0.612-0.769)
  (C) TDRD9 ROC - CD training  (GSE94648)   expected AUC 0.696 (0.577-0.809)
  (D) TDRD9 ROC - MDD training (GSE98793)   expected AUC 0.691 (0.612-0.767)
"""
import os
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, auc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.linewidth": 0.8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "in", "ytick.direction": "in",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.3,
})

def load_expr(f):
    df = pd.read_csv(f, index_col=0)
    return df.T if df.shape[1] > df.shape[0] else df

def load_groups(f):
    with open(f) as fh:
        return [l.strip() for l in fh.readlines() if l.strip()]

expr_cd = load_expr(os.path.join(SRC, "Exprs_CD_key.csv"))
expr_mdd = load_expr(os.path.join(SRC, "Exprs_MDD_key.csv"))
g_cd = load_groups(os.path.join(SRC, "Groups_CD.txt"))
g_mdd = load_groups(os.path.join(SRC, "Groups_MDD.txt"))
g_mdd = [g if g != "MDD_with_GAD" else "MDD_with_GAD" for g in g_mdd]

def roc(ax, exprs, groups, gene, title, color, y_true=None):
    vals = exprs[gene].values[:len(groups)]
    if y_true is None:
        y_true = np.array([1 if g != "Control" else 0 for g in groups[:len(vals)]])
    fpr, tpr, _ = roc_curve(y_true, vals)
    roc_auc = auc(fpr, tpr)
    boot = []
    rng = np.random.RandomState(42)
    for _ in range(2000):
        idx = rng.choice(len(y_true), len(y_true), replace=True)
        if len(np.unique(y_true[idx])) < 2:
            continue
        boot.append(auc(*roc_curve(y_true[idx], vals[idx])[:2]))
    lo, hi = np.percentile(boot, [2.5, 97.5])
    ax.plot(fpr, tpr, color=color, lw=1.5, label="AUC = %.3f (95%% CI %.3f\u2013%.3f)" % (roc_auc, lo, hi))
    ax.plot([0, 1], [0, 1], "k--", lw=0.6, alpha=0.5)
    ax.set_xlabel("1 \u2212 Specificity", fontsize=7)
    ax.set_ylabel("Sensitivity", fontsize=7)
    ax.set_title(title, fontsize=8, fontweight="bold", pad=5)
    ax.legend(fontsize=6.5, loc="lower right", frameon=True, edgecolor="grey")
    ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
    print("  ROC %s: AUC %.3f (%.3f-%.3f)" % (title[:32], roc_auc, lo, hi))

fig, axes = plt.subplots(2, 2, figsize=(9.5, 8.5))
roc(axes[0, 0], expr_cd, g_cd, "MMP8", "A: MMP8 ROC \u2014 CD Training (GSE94648)", "#E53935")
roc(axes[0, 1], expr_mdd, g_mdd, "MMP8", "B: MMP8 ROC \u2014 MDD Training (GSE98793)", "#1E88E5")
roc(axes[1, 0], expr_cd, g_cd, "TDRD9", "C: TDRD9 ROC \u2014 CD Training (GSE94648)", "#E53935")
roc(axes[1, 1], expr_mdd, g_mdd, "TDRD9", "D: TDRD9 ROC \u2014 MDD Training (GSE98793)", "#1E88E5")

plt.tight_layout(pad=1.6)
for ext in ["pdf", "png"]:
    p = os.path.join(OUT, "Figure_3_updated.%s" % ext)
    fig.savefig(p, dpi=300)
    print("Saved:", p)
plt.close(fig)
from PIL import Image
im = Image.open(os.path.join(OUT, "Figure_3_updated.png"))
im.save(os.path.join(OUT, "Figure_3_updated.tif"), compression="tiff_lzw")
print("Saved: Figure_3_updated.tif (LZW)")