import pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 9, "figure.dpi": 300, "savefig.dpi": 300,
})

OUT = r"D:\投稿相关\CD_MDD\EJPS_submission\Figures"
os.makedirs(OUT, exist_ok=True)

CD = pd.read_csv(r"E:\IBD\cd\DEG_CD_full.csv")
M1 = pd.read_csv(r"E:\IBD\cd\DEG_MDD_full.csv")       # MDD with-GAD
M2 = pd.read_csv(r"E:\IBD\cd\DEG_MDD_noGAD_full.csv") # MDD without-GAD

cand = ["CRISP3","GRB10","MMP8","S100A12","TDRD9","TNNT1","BCL11A","COBLL1","MS4A1"]
cohorts = [("CD training\n(GSE94648)", CD),
           ("MDD with-GAD\n(GSE98793-1)", M1),
           ("MDD w/o GAD\n(GSE98793-2)", M2)]

def get(df, gene):
    r = df[df['Gene']==gene]
    if len(r)==0: return (0.0, 1.0)
    r=r.iloc[0]; return (float(r['logFC']), float(r['adj.P.Val']))

# build signed -log10(adj.P) matrix
M = np.zeros((len(cand),3))
raw = {}
for j,(name,df) in enumerate(cohorts):
    for i,g in enumerate(cand):
        lfc,ap = get(df,g)
        raw[(g,name)] = (lfc,ap)
        M[i,j] = np.sign(lfc)* (-np.log10(max(ap,1e-10)))

Mclip = np.clip(M, -3, 3)

fig, ax = plt.subplots(figsize=(6.8,6.4), dpi=300)
im = ax.imshow(Mclip, cmap=plt.cm.RdBu_r, vmin=-3, vmax=3, aspect='auto')

for i,g in enumerate(cand):
    for j,(name,df) in enumerate(cohorts):
        lfc,ap = raw[(g,name)]
        arrow = "▲" if lfc>0 else "▼"
        col = "white" if abs(Mclip[i,j])>1.6 else "black"
        apstr = ("%.1e"%ap) if ap<0.001 else ("%.3f"%ap)
        ax.text(j, i, f"{arrow}\n{apstr}", ha='center', va='center', fontsize=9, color=col)

ax.set_xticks(range(3)); ax.set_xticklabels([c[0] for c in cohorts], fontsize=9.5)
ax.set_yticks(range(len(cand))); ax.set_yticklabels(cand, fontsize=10, fontweight='bold')

cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label("signed -log10(adj.P.Val)", fontsize=9)

note = ("Red = up-regulated; blue = down-regulated. Color intensity reflects adj.P.\n"
        "CD: FDR<0.05 for all except MMP8 (adj.P=0.182). MDD cohorts: relaxed thresholds\n"
        "(FDR<0.2 or P<0.01); see Methods. 6 up / 3 down in CD and MDD-w/o-GAD.")
fig.text(0.5, 0.015, note, ha='center', fontsize=7.5, style='italic', color='#444')

plt.tight_layout(rect=[0,0.06,1,1])
for ext in ["png","pdf"]:
    fig.savefig(os.path.join(OUT, f"Figure_1C_updated.{ext}"), dpi=300, bbox_inches='tight')
from PIL import Image
Image.open(os.path.join(OUT,"Figure_1C_updated.png")).save(os.path.join(OUT,"Figure_1C_updated.tif"), dpi=(300,300))
plt.close()
print("Figure_1C_updated written")
