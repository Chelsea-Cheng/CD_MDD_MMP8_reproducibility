#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Regenerate Figure 2B: MMP8 in CD validation cohort (GSE169568), unified 82-sample
design (30 healthy controls + 52 CD patients) -- same cohort as the TDRD9
validation. MMP8 probe (ILMN_1736026) was recovered from the non-normalized
GSE169568 data (row 147-sample file, subset to the 82 primary-analysis samples).
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"

e147 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key_fixed.csv"), index_col=0)
e82 = pd.read_csv(os.path.join(SRC, "Exprs_CD_val_key.csv"), index_col=0)
ids82 = e82.columns.tolist()
g82 = pd.read_csv(os.path.join(SRC, "Groups_CD_val.txt"), header=None)[0].tolist()

mmp8 = e147.loc["MMP8", ids82].astype(float).values
grp = np.array([x.strip() for x in g82])
ctrl = mmp8[grp == "Control"]
cd = mmp8[grp == "CD"]
print("n=%d (Control=%d, CD=%d)" % (len(mmp8), len(ctrl), len(cd)))

u, p_mw = stats.mannwhitneyu(cd, ctrl, alternative="two-sided")
y = (grp == "CD").astype(int)
auc = roc_auc_score(y, mmp8)
rng = np.random.default_rng(42)
boot = []
for _ in range(2000):
    idx = rng.integers(0, len(y), len(y))
    if len(np.unique(y[idx])) < 2:
        continue
    try:
        boot.append(roc_auc_score(y[idx], mmp8[idx]))
    except Exception:
        pass
ci_low, ci_high = np.percentile(boot, [2.5, 97.5])
print("Mann-Whitney p = %.4f | AUC = %.3f (95%% CI %.3f-%.3f)" % (p_mw, auc, ci_low, ci_high))
print("medians: Control %.3f vs CD %.3f" % (np.median(ctrl), np.median(cd)))
fpr, tpr, _ = roc_curve(y, mmp8)

fig, axes = plt.subplots(2, 1, figsize=(5.2, 8.4))
fig.suptitle("Figure 2B. MMP8 in the CD validation cohort (GSE169568)",
             fontsize=12, fontweight="bold", y=0.98)

ax0 = axes[0]
data = [ctrl, cd]
bp = ax0.boxplot(data, positions=[1, 2], widths=0.5, patch_artist=True,
                 showfliers=False, medianprops=dict(color="black"))
colors = ["#7fb3d5", "#e74c3c"]
for patch, c in zip(bp["boxes"], colors):
    patch.set_facecolor(c)
    patch.set_alpha(0.75)
for i, (vals, c) in enumerate(zip(data, colors), start=1):
    x = np.random.normal(i, 0.06, len(vals))
    ax0.scatter(x, vals, s=14, color=c, alpha=0.6, edgecolor="white", linewidth=0.4)
ax0.set_xticks([1, 2])
ax0.set_xticklabels(["Control\n(n=%d)" % len(ctrl), "CD\n(n=%d)" % len(cd)], fontsize=10)
ax0.set_ylabel("MMP8 expression (log2)", fontsize=10)
ax0.set_title("MMP8 expression by group", fontsize=10.5, loc="left")
ax0.text(0.02, 0.96, "Mann\u2013Whitney p = %.3f" % p_mw, transform=ax0.transAxes,
         fontsize=9.5, va="top", fontweight="bold")
ax0.grid(axis="y", alpha=0.3)

ax1 = axes[1]
ax1.plot(fpr, tpr, color="#2c3e50", lw=2.2, label="MMP8 (AUC = %.3f)" % auc)
ax1.plot([0, 1], [0, 1], "--", color="gray", lw=1)
ax1.set_xlabel("1 \u2013 Specificity", fontsize=10)
ax1.set_ylabel("Sensitivity", fontsize=10)
ax1.set_title("ROC (95%% CI %.2f\u2013%.2f)" % (ci_low, ci_high), fontsize=10.5, loc="left")
ax1.legend(loc="lower right", fontsize=9)
ax1.grid(alpha=0.3)

plt.tight_layout(rect=[0, 0, 1, 0.96])
for ext in ["png", "pdf", "tif"]:
    p = os.path.join(OUT, "Figure_2B_updated.%s" % ext)
    fig.savefig(p, dpi=300, bbox_inches="tight")
    print("Saved:", p)
plt.close(fig)

with open(os.path.join(SRC, "fig2b_82_stats.txt"), "w") as f:
    f.write("n=%d Control=%d CD=%d\n" % (len(mmp8), len(ctrl), len(cd)))
    f.write("MW_p=%.4f AUC=%.3f CI95=%.3f-%.3f\n" % (p_mw, auc, ci_low, ci_high))
    f.write("median_ctrl=%.3f median_cd=%.3f\n" % (np.median(ctrl), np.median(cd)))