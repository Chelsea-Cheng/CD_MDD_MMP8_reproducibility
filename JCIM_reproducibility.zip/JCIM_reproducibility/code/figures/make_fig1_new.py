#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
New Figure 1 (revised main-text figure), 2x2 layout:
  (A) CD training volcano (GSE94648)  - rule: (P<0.01|adjP<0.2) & |log2FC|>0.3 -> 1068 DEGs
  (B) MDD-with-GAD volcano (GSE98793) - rule: (P<0.01|adjP<0.2) & |log2FC|>0.2 -> 79 DEGs
  (C) 3-set Venn (CD x MDD+GAD x MDD-GAD) with 9 direction-consistent candidates
  (D) 9-gene x 3-cohort direction-consistent panel (from Figure_1C_updated)
Layout: top row = volcanos A/B, bottom row = Venn C + panel D (avoids yellow-box overlap).
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib_venn import venn3
import warnings
warnings.filterwarnings("ignore")

SRC = "E:/IBD/cd"
OUT = "D:/投稿相关/CD_MDD/EJPS_submission/Figures"
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 8, "axes.linewidth": 0.8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "in", "ytick.direction": "in",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 300,
})

COL = {"NS": "#B0B0B0", "Up": "#D32F2F", "Down": "#1976D2"}

def prepare(df, fc_t):
    df = df.copy()
    sig = ((df["P.Value"] < 0.01) | (df["adj.P.Val"] < 0.2)) & (df["logFC"].abs() > fc_t)
    df["sig"] = "NS"
    df.loc[sig & (df.logFC > 0), "sig"] = "Up"
    df.loc[sig & (df.logFC < 0), "sig"] = "Down"
    df["neg_log10"] = -np.log10(df["P.Value"].clip(lower=1e-300))
    return df

def volcano(ax, df, fc_t, labels, panel):
    d = prepare(df, fc_t)
    for t in ["NS", "Up", "Down"]:
        s = d[d.sig == t]
        ax.scatter(s.logFC, s.neg_log10, c=COL[t], s=3, alpha=0.5,
                   edgecolors="none", rasterized=True)
    lbl = d[d.Gene.isin(labels)]
    for _, r in lbl.iterrows():
        ax.annotate(r["Gene"], (r.logFC, r.neg_log10), fontsize=7, fontweight="bold",
                    color="#333333", ha="center", va="bottom",
                    arrowprops=dict(arrowstyle="-", color="#999999", lw=0.4))
    ax.axvline(-fc_t, color="grey", ls="--", lw=0.4, alpha=0.5)
    ax.axvline(fc_t, color="grey", ls="--", lw=0.4, alpha=0.5)
    ax.set_xlabel("log2(Fold Change)", fontsize=8)
    ax.set_ylabel("$-$log10(P-value)", fontsize=8)
    n_up = int((d.sig == "Up").sum()); n_down = int((d.sig == "Down").sum())
    print("  panel %s: Up=%d Down=%d NS=%d" % (panel, n_up, n_down, int((d.sig == "NS").sum())))
    ax.legend(handles=[Line2D([0],[0], marker="o", color="w", markerfacecolor=COL["Up"], markersize=5, label="Up (n=%d)" % n_up),
                       Line2D([0],[0], marker="o", color="w", markerfacecolor=COL["Down"], markersize=5, label="Down (n=%d)" % n_down)],
              fontsize=6, loc="upper right", frameon=True, facecolor="white", edgecolor="grey", framealpha=0.8)
    ax.text(0.02, 0.97, panel, transform=ax.transAxes, fontsize=12, fontweight="bold",
            va="top", ha="left")

def venn_panel(ax, fig=None):
    if fig is None:
        fig = ax.figure
    cd = pd.read_csv(os.path.join(SRC, "DEG_CD_full.csv"))
    gad = pd.read_csv(os.path.join(SRC, "DEG_MDD_full.csv"))
    nogad = pd.read_csv(os.path.join(SRC, "DEG_MDD_noGAD_full.csv"))
    m_cd = ((cd["P.Value"] < 0.01) | (cd["adj.P.Val"] < 0.2)) & (cd["logFC"].abs() > 0.3)
    def mdd_sets(d):
        m = ((d["P.Value"] < 0.01) | (d["adj.P.Val"] < 0.2)) & (d["logFC"].abs() > 0.2)
        return set(d[m & (d.logFC > 0)].Gene), set(d[m & (d.logFC < 0)].Gene)
    up_cd, dn_cd = set(cd[m_cd & (cd.logFC > 0)].Gene), set(cd[m_cd & (cd.logFC < 0)].Gene)
    up_gad, dn_gad = mdd_sets(gad)
    up_nog, dn_nog = mdd_sets(nogad)
    A, B, C = up_cd | dn_cd, up_gad | dn_gad, up_nog | dn_nog
    subsets = (len(A - B - C), len(B - A - C), len((A & B) - C),
               len(C - A - B), len((A & C) - B), len((B & C) - A), len(A & B & C))
    print("  venn subsets (100,010,110,001,101,011,111):", subsets)
    v = venn3(subsets=subsets,
              set_labels=("CD training\n(GSE94648, n=%d)" % len(A),
                          "MDD with GAD\n(GSE98793, n=%d)" % len(B),
                          "MDD without GAD\n(GSE98793, n=%d)" % len(C)),
              set_colors=("#E53935", "#1E88E5", "#7CB342"), alpha=0.45, ax=ax,
              normalize_to=0.82)
    for lab in ["100", "010", "110", "001", "101", "011", "111"]:
        l = v.get_label_by_id(lab)
        if l is not None:
            l.set_fontsize(13); l.set_fontweight("bold")
    for t in v.set_labels:
        if t is not None:
            t.set_fontsize(11); t.set_fontweight("bold")
    ax.text(0.02, 0.97, "C", transform=ax.transAxes, fontsize=12, fontweight="bold",
            va="top", ha="left")
    ax.set_aspect("equal")
    return len(A), len(B), len(C)

cd = pd.read_csv(os.path.join(SRC, "DEG_CD_full.csv"))
gad = pd.read_csv(os.path.join(SRC, "DEG_MDD_full.csv"))

fig, axes = plt.subplots(2, 2, figsize=(13.5, 11.5),
                         gridspec_kw={"height_ratios": [1.15, 1.0],
                                      "hspace": 0.32, "wspace": 0.24})
volcano(axes[0, 0], cd, 0.3, ["MMP8", "TDRD9", "S100A12", "BCL11A"], "A")
axes[0, 0].set_title("Crohn\u2019s disease training (GSE94648)", fontsize=9.5, fontweight="bold", pad=6)
volcano(axes[0, 1], gad, 0.2, ["MMP8", "TDRD9"], "B")
axes[0, 1].set_title("MDD with comorbid GAD (GSE98793)", fontsize=9.5, fontweight="bold", pad=6)
venn_panel(axes[1, 0], fig)

im = plt.imread(os.path.join(OUT, "Figure_1C_updated.png"))
axes[1, 1].imshow(im)
axes[1, 1].axis("off")

plt.tight_layout(pad=1.2, h_pad=0.5)
fig.canvas.draw()
pos_c = axes[1, 0].get_position()
pos_d = axes[1, 1].get_position()
fig.text((pos_c.x0 + pos_c.x1) / 2, 0.01,
         "9 direction-consistent candidate DEGs (Table 1)\n"
         "Triple overlap (12): MMP8, TDRD9 (up)\n"
         "CD \u2229 with-GAD (3): CRISP3 (up)\n"
         "CD \u2229 without-GAD (89): GRB10, S100A12, TNNT1 (up); "
         "BCL11A, COBLL1, MS4A1 (down)",
         ha="center", va="bottom", fontsize=9, zorder=10,
         bbox=dict(boxstyle="round,pad=0.4", fc="#fdf6ec", ec="#d9a94e", lw=1.1))
for ax, letter in [(axes[1, 0], "C"), (axes[1, 1], "D")]:
    pos = ax.get_position()
    fig.text(pos.x0 + 0.005, pos.y1 + 0.012, letter, fontsize=13, fontweight="bold",
             va="bottom", ha="left")

for ext in ["pdf", "png"]:
    p = os.path.join(OUT, "Figure_1_updated.%s" % ext)
    fig.savefig(p, dpi=300, bbox_inches="tight", pad_inches=0.35)
    print("Saved:", p)
plt.close(fig)
from PIL import Image
im = Image.open(os.path.join(OUT, "Figure_1_updated.png"))
im.save(os.path.join(OUT, "Figure_1_updated.tif"), compression="tiff_lzw")
print("Saved: Figure_1_updated.tif (LZW)")