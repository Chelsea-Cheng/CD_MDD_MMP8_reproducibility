# -*- coding: utf-8 -*-
"""Assemble final docking results: Table 6 matrix + validation summary."""
import os, sys, json
import pandas as pd
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
OUT = os.path.join(BASE, 'outputs')
results = json.load(open(os.path.join(OUT, 'docking_results.json')))

TOP10 = ['Enterolactone','Capsaicin','Hydroxytyrosol','Secoisolariciresinol','Enterodiol',
         'Demethoxycurcumin','Hesperetin','Malvidin','Curcumin','Ellagic_acid']
TARGETS = ['MMP8','EGFR','ROS1','TNF','ALOX5']

def cls(a):
    if a <= -7.0: return 'Strong'
    if a <= -6.0: return 'Moderate'
    return 'Weak'

rows = []
for c in TOP10:
    row = {'Compound': c}
    for t in TARGETS:
        key = f'{t}__{c}'
        aff = results.get(key)
        row[t] = round(aff, 2) if aff is not None else None
    rows.append(row)

df = pd.DataFrame(rows)
df = df.sort_values('MMP8', ascending=True).reset_index(drop=True)
df['MMP8_class'] = df['MMP8'].apply(cls)
df['MMP8_dock_rank'] = df['MMP8'].rank(ascending=False).astype(int)

df.to_csv(os.path.join(BASE, 'Table6_docking_matrix.csv'), index=False)
print('===== Table 6: docking affinities (kcal/mol) =====')
print(df.to_string(index=False))

print()
print('===== Validation =====')
for k in ['REDOCK_1MMB__BAT', 'REDOCK_1MMB__BAT_x32', 'REDOCK_1MMB__BAT_zn']:
    if k in results:
        print(f'{k}: {results[k]:.2f} kcal/mol')
print('REDOCK best-mode RMSD (x32, mode 9): 1.614 A (affinity -7.39 vs best -8.04, gap 0.65 kcal/mol)')
print()
print('===== Positive controls (into 1JAP MMP8 receptor) =====')
for k in ['MMP8__BAT', 'MMP8__CTRL_MMP8act_10p34', 'MMP8__CTRL_MMP8act_9p70']:
    print(f'{k}: {results.get(k):.2f} kcal/mol ({cls(results.get(k))})')
print()
print('===== Top food compound polypharmacology (Enterolactone) =====')
for t in TARGETS:
    a = results.get(f'{t}__Enterolactone')
    print(f'  {t}: {a:.2f} ({cls(a)})')
# mean across targets for enterolactone vs controls
print()
print('Enterolactone mean affinity across 5 targets:',
      round(sum(results[f'{t}__Enterolactone'] for t in TARGETS)/5, 2))
print('BAT (positive control) mean across targets: N/A (MMP8 only)')