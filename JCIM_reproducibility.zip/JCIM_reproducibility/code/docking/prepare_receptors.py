# -*- coding: utf-8 -*-
"""Prepare receptors: clean PDB (remove HOH + ligands, keep metals) -> PDBQT via obabel."""
import os, subprocess, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
REC = os.path.join(BASE, 'receptors')
OBABEL = r'C:\Python312\Lib\site-packages\openbabel\bin\obabel.exe'

# target -> (pdb file, residues to remove as HETATM, metals to KEEP)
JOBS = {
    'EGFR':  ('EGFR_1M17.pdb', {'AQ4'}, set()),          # keep no metals
    'ROS1':  ('ROS1_3ZBF.pdb', {'VGH'}, set()),
    'TNF':   ('TNF_2AZ5.pdb',  {'307'}, set()),
    'ALOX5': ('ALOX5_3O8Y.pdb', {'HOH'}, {'FE2'}),       # keep catalytic iron
    'MMP8_1MMB': ('MMP8_1MMB.pdb', {'BAT', 'HOH'}, {'ZN'}),  # redock validation receptor
}

for name, (pdb, remove, keep) in JOBS.items():
    src = os.path.join(REC, pdb)
    clean = os.path.join(REC, f'{name}_clean.pdb')
    pdbqt = os.path.join(REC, f'{name}.pdbqt')
    out_lines = []
    removed = 0
    for l in open(src, encoding='utf-8', errors='replace'):
        if l.startswith('HETATM'):
            res = l[17:20].strip()
            if res in remove:
                removed += 1
                continue
            if res not in keep and res != 'HOH':
                # remove other small molecules (ions/crystallization agents)
                removed += 1
                continue
        if l.startswith('HOH'):
            continue
        out_lines.append(l.rstrip('\n'))
        if l.startswith('END'):
            break
    open(clean, 'w', encoding='utf-8').write('\n'.join(out_lines))
    cmd = [OBABEL, clean, '-O', pdbqt, '-xr']
    r = subprocess.run(cmd, capture_output=True, text=True)
    ok = os.path.exists(pdbqt) and os.path.getsize(pdbqt) > 3000
    print(f'{name}: cleaned (removed {removed} HETATM) -> PDBQT {os.path.getsize(pdbqt) if os.path.exists(pdbqt) else 0}B ok={ok}')
    if not ok:
        print('  ', r.stderr[-500:] if r.stderr else 'NO STDERR')