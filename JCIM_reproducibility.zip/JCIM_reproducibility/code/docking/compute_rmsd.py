# -*- coding: utf-8 -*-
"""Compute redocking RMSD: docked BAT pose (from 1MMB receptor output) vs BAT crystal pose.
Greedy element-constrained nearest-atom matching on heavy atoms."""
import os, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
LIG = os.path.join(BASE, 'ligands')
OUT = os.path.join(BASE, 'outputs')

def read_coords(path, tag=None):
    atoms = []
    for l in open(path, encoding='utf-8', errors='replace'):
        if l.startswith(('ATOM', 'HETATM')):
            name = l[12:16].strip()
            elem = l[76:78].strip() if len(l) > 76 else ''
            if not elem:
                elem = name[0]
            x, y, z = float(l[30:38]), float(l[38:46]), float(l[46:54])
            if tag is None or tag in l[21]:
                atoms.append((name, elem.upper(), np.array([x, y, z])))
    return atoms

# crystal BAT (from 1MMB)
crystal = read_coords(os.path.join(LIG, 'BAT_crystal.pdb'))
# docked BAT pose (vina output mode 1 = first MODEL)
docked = []
model_seen = False
for l in open(os.path.join(OUT, 'REDOCK_1MMB__BAT_out.pdbqt'), encoding='utf-8', errors='replace'):
    if l.startswith('MODEL'):
        model_seen = True
        docked = []
        continue
    if l.startswith('ENDMDL'):
        if model_seen:
            break
    if l.startswith(('ATOM', 'HETATM')):
        name = l[12:16].strip()
        elem = (l[76:78].strip() if len(l) > 76 else name[0]).upper()
        docked.append((name, elem, np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])])))

print(f'Crystal atoms: {len(crystal)}, Docked atoms (mode 1): {len(docked)}')

heavy_c = [a for a in crystal if a[1] != 'H']
heavy_d = [a for a in docked if a[1] != 'H']
print(f'Heavy atoms: crystal={len(heavy_c)}, docked={len(heavy_d)}')

# greedy matching: for each crystal heavy atom, nearest unused docked atom of same element
used = set()
pairs = []
import scipy.spatial as sp
if len(heavy_d) != len(heavy_c):
    print('WARNING: atom count mismatch; matching min count')
n = min(len(heavy_c), len(heavy_d))
for i in range(len(heavy_c)):
    best_d, best_dist = None, 1e9
    for j, d in enumerate(heavy_d):
        if j in used:
            continue
        if d[1] == heavy_c[i][1]:
            dist = np.linalg.norm(heavy_c[i][2] - d[2])
            if dist < best_dist:
                best_dist, best_d = dist, j
    if best_d is not None:
        used.add(best_d)
        pairs.append((heavy_c[i][2], heavy_d[best_d][2], heavy_c[i][1], best_dist))

coords_c = np.array([p[0] for p in pairs])
coords_d = np.array([p[1] for p in pairs])
# RMSD without alignment (same receptor frame)
rmsd_raw = np.sqrt(((coords_c - coords_d) ** 2).sum(axis=1).mean())
# RMSD after optimal rigid alignment (Kabsch)
c0, d0 = coords_c.mean(axis=0), coords_d.mean(axis=0)
H = (coords_d - d0).T @ (coords_c - c0)
U, S, Vt = np.linalg.svd(H)
R = Vt.T @ U.T
if np.linalg.det(R) < 0:
    Vt[-1, :] *= -1
    R = Vt.T @ U.T
aligned = (coords_d - d0) @ R.T + c0
rmsd_kabsch = np.sqrt(((coords_c - aligned) ** 2).sum(axis=1).mean())

print(f'Matched pairs: {len(pairs)}')
print(f'RMSD (no alignment, same frame): {rmsd_raw:.3f} A')
print(f'RMSD (Kabsch aligned):            {rmsd_kabsch:.3f} A')
print('Per-atom distances (crystal atom, element, distance):')
for c_, d_, el, dist in pairs:
    print(f'  {el:2s} {dist:6.3f} A')