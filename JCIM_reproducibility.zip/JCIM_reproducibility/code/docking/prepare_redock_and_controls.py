# -*- coding: utf-8 -*-
"""Prepare redock ligand (BAT from 1MMB) + positive controls via obabel --gen3d (RDKit path-safe)."""
import os, subprocess, sys, json
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
LIG = os.path.join(BASE, 'ligands')
REC = os.path.join(BASE, 'receptors')
OBABEL = r'C:\Python312\Lib\site-packages\openbabel\bin\obabel.exe'

# 1) extract BAT crystal pose from 1MMB
mmb = open(os.path.join(REC, 'MMP8_1MMB.pdb'), encoding='utf-8', errors='replace').read().split('\n')
bat = [l for l in mmb if l.startswith('HETATM') and l[17:20].strip() == 'BAT']
conect = [l for l in mmb if l.startswith('CONECT')]
open(os.path.join(LIG, 'BAT_crystal.pdb'), 'w').write('\n'.join(bat + conect) + '\nEND\n')
r = subprocess.run([OBABEL, os.path.join(LIG, 'BAT_crystal.pdb'), '-O', os.path.join(LIG, 'BAT.pdbqt'), '-p', '7.4'],
                   capture_output=True, text=True)
print(f'BAT crystal: {len(bat)} atoms -> PDBQT ok={os.path.exists(os.path.join(LIG, "BAT.pdbqt"))}')

# BAT crystal center (grid for redocking)
import numpy as np
c = np.array([[float(l[30:38]), float(l[38:46]), float(l[46:54])] for l in bat])
bat_center = [round(c[:,0].mean(), 3), round(c[:,1].mean(), 3), round(c[:,2].mean(), 3)]
print('BAT crystal center:', bat_center)

# 2) positive controls: BAT (crystal-derived PDBQT, serves as 1st control on 1JAP receptor)
#    + 2 most potent ChEMBL MMP8 actives (via obabel --gen3d)
controls = {}
import pandas as pd
df = pd.read_csv(r'E:\IBD\cd\ChEMBL_IC50_Data.csv')
mmp8 = df[df.target == 'MMP8'].drop_duplicates('smiles').sort_values('pIC50', ascending=False)
for i, row in mmp8.head(2).iterrows():
    name = f'CTRL_MMP8act_{row.pIC50:.2f}'.replace('.', 'p')
    controls[name] = row.smiles
print('ChEMBL positive controls:', list(controls.keys()))

for name, smi in controls.items():
    out = os.path.join(LIG, f'{name}.pdbqt')
    r = subprocess.run([OBABEL, f'-:{smi}', '-O', out, '--gen3d', '-p', '7.4'],
                       capture_output=True, text=True, cwd=BASE)
    ok = os.path.exists(out) and os.path.getsize(out) > 800
    print(f'{name}: ok={ok} size={os.path.getsize(out) if os.path.exists(out) else 0}')
    if not ok:
        print('   ', r.stderr[-300:] if r.stderr else '', r.stdout[-300:] if r.stdout else '')

# 3) update grids.json with redock grid
g = json.load(open(os.path.join(BASE, 'grids.json')))
g['centers']['MMP8_1MMB'] = bat_center
g['box']['MMP8_1MMB'] = 24.0
json.dump(g, open(os.path.join(BASE, 'grids.json'), 'w'), indent=2)
print('grids.json updated:', g['centers']['MMP8_1MMB'])