# -*- coding: utf-8 -*-
"""Prepare ligands:
1) copy top-10 compound PDBQTs from E:\\IBD\\cd\\ligands
2) extract HOA (co-crystallized PLG-hydroxylamine) from MMP8_1JAP for redocking
3) build 2 known MMP8 inhibitor positive controls from ChEMBL_IC50_Data.csv (2 most potent)
"""
import os, shutil, subprocess, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
LIG = os.path.join(BASE, 'ligands')
SRC_LIG = r'E:\IBD\cd\ligands'
REC = os.path.join(BASE, 'receptors')
OBABEL = r'C:\Python312\Lib\site-packages\openbabel\bin\obabel.exe'
sys.path.insert(0, BASE)

TOP10 = ['Enterolactone','Capsaicin','Hydroxytyrosol','Secoisolariciresinol','Enterodiol',
         'Demethoxycurcumin','Hesperetin','Malvidin','Curcumin','Ellagic_acid']

# 1) copy top-10
for c in TOP10:
    shutil.copy(os.path.join(SRC_LIG, f'{c}.pdbqt'), os.path.join(LIG, f'TOP_{c}.pdbqt'))
print(f'Copied {len(TOP10)} top-10 PDBQTs')

# 2) extract HOA from 1JAP (chain I, res HOA)
jap = open(os.path.join(REC, 'MMP8_1JAP.pdb'), encoding='utf-8', errors='replace').read().split('\n')
hoa = []
for l in jap:
    if l.startswith('HETATM') and l[21] == 'I' and l[17:20].strip() == 'HOA':
        hoa.append(l)
# keep CONECT records for HOA
conect = [l for l in jap if l.startswith('CONECT')]
hoa_pdb = '\n'.join(hoa + conect) + '\nEND\n'
open(os.path.join(LIG, 'HOA_crystal.pdb'), 'w').write(hoa_pdb)
# polar H add + PDBQT
r = subprocess.run([OBABEL, os.path.join(LIG, 'HOA_crystal.pdb'), '-O', os.path.join(LIG, 'HOA.pdbqt'), '-p', '7.4'],
                   capture_output=True, text=True)
print(f'HOA extracted: {len(hoa)} atoms -> PDBQT ok={os.path.exists(os.path.join(LIG,"HOA.pdbqt"))}')

# 3) positive controls: 2 most potent MMP8 actives from ChEMBL
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem
df = pd.read_csv(r'E:\IBD\cd\ChEMBL_IC50_Data.csv')
mmp8 = df[df.target == 'MMP8'].sort_values('pIC50', ascending=False).drop_duplicates('smiles')
controls = []
for i, row in mmp8.head(2).iterrows():
    name = f'CTRL_MMP8act_{row.pIC50:.2f}'.replace('.', 'p')
    mol = Chem.MolFromSmiles(row.smiles)
    molH = Chem.AddHs(mol)
    AllChem.EmbedMolecule(molH, randomSeed=42)
    AllChem.MMFFOptimizeMolecule(molH)
    sdf = os.path.join(LIG, f'{name}.sdf')
    w = Chem.SDWriter(sdf)
    w.write(molH)
    w.close()
    pdbqt = os.path.join(LIG, f'{name}.pdbqt')
    subprocess.run([OBABEL, sdf, '-O', pdbqt], capture_output=True, text=True)
    controls.append((name, row.smiles[:60], row.pIC50))
    print(f'Control {name}: pIC50={row.pIC50:.2f}, PDBQT ok={os.path.exists(pdbqt)}')

# grid centers per target (from crystal ligand / metal)
import json
centers = {
    'MMP8':  [21.688, 68.984, 55.297],   # catalytic Zn (existing)
    'EGFR':  [22.014, 0.253, 52.794],    # AQ4 erlotinib
    'ROS1':  [42.792, 19.685, 4.227],    # VGH
    'TNF':   [-19.410, 74.651, 33.850],  # 307 chain A (trimer interface)
    'ALOX5': [4.049, 21.347, -0.284],    # catalytic Fe2 chain A
}
box = {'MMP8': 22.0, 'EGFR': 22.0, 'ROS1': 22.0, 'TNF': 26.0, 'ALOX5': 24.0}
json.dump({'centers': centers, 'box': box}, open(os.path.join(BASE, 'grids.json'), 'w'), indent=2)
print('grids.json saved:', centers, box)