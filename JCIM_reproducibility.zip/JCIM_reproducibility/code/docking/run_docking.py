# -*- coding: utf-8 -*-
"""Run AutoDock Vina docking: 10 compounds x 5 targets + BAT redock + controls.
Resumable (skips existing outputs). Writes per-job log + parsed results json."""
import os, subprocess, sys, json, glob, time
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
REC = os.path.join(BASE, 'receptors')
LIG = os.path.join(BASE, 'ligands')
OUT = os.path.join(BASE, 'outputs')
VINA = os.path.join(BASE, 'vina.exe')

grids = json.load(open(os.path.join(BASE, 'grids.json')))
centers, box = grids['centers'], grids['box']

TOP10 = ['Enterolactone','Capsaicin','Hydroxytyrosol','Secoisolariciresinol','Enterodiol',
         'Demethoxycurcumin','Hesperetin','Malvidin','Curcumin','Ellagic_acid']

TARGETS = ['MMP8','EGFR','ROS1','TNF','ALOX5']

# build job list: (label, receptor_pdbqt, ligand_pdbqt, center, box)
jobs = []
for t in TARGETS:
    for c in TOP10:
        jobs.append((f'{t}__{c}',
                     os.path.join(REC, f'{t}.pdbqt'),
                     os.path.join(LIG, f'TOP_{c}.pdbqt'),
                     centers[t], box[t]))
# redocking validation: BAT into 1MMB receptor
jobs.append(('REDOCK_1MMB__BAT',
             os.path.join(REC, 'MMP8_1MMB.pdbqt'),
             os.path.join(LIG, 'BAT.pdbqt'),
             centers['MMP8_1MMB'], box['MMP8_1MMB']))
# positive controls into 1JAP-based MMP8 receptor
for ctrl in ['BAT.pdbqt','CTRL_MMP8act_10p34.pdbqt','CTRL_MMP8act_9p70.pdbqt']:
    jobs.append((f'MMP8__{ctrl.replace(".pdbqt","")}',
                 os.path.join(REC, 'MMP8.pdbqt'),
                 os.path.join(LIG, ctrl),
                 centers['MMP8'], box['MMP8']))

print(f'Total jobs: {len(jobs)}')

def parse_affinity(out_pdbqt_path, log_path):
    best = None
    if os.path.exists(out_pdbqt_path):
        for l in open(out_pdbqt_path, encoding='utf-8', errors='replace'):
            if l.startswith('REMARK VINA RESULT'):
                best = float(l.split()[3])
                break
    if best is None and os.path.exists(log_path):
        for l in open(log_path, encoding='utf-8', errors='replace'):
            if '1' == l.strip().split('\t')[0] and '\t' in l:
                try:
                    best = float(l.split()[1])
                except Exception:
                    pass
                break
    return best

def run_job(job):
    label, rec, lig, ctr, sz = job
    out_pdbqt = os.path.join(OUT, f'{label}_out.pdbqt')
    log = os.path.join(OUT, f'{label}_log.txt')
    if os.path.exists(out_pdbqt):
        return label, 'SKIP', parse_affinity(out_pdbqt, log)
    cfg = os.path.join(OUT, f'{label}_cfg.txt')
    with open(cfg, 'w') as f:
        f.write(f'receptor = {rec}\nligand = {lig}\n')
        f.write(f'center_x = {ctr[0]}\ncenter_y = {ctr[1]}\ncenter_z = {ctr[2]}\n')
        f.write(f'size_x = {sz}\nsize_y = {sz}\nsize_z = {sz}\n')
        f.write('exhaustiveness = 8\nnum_modes = 9\nenergy_range = 3\n')
        f.write(f'out = {out_pdbqt}\n')
    t0 = time.time()
    r = subprocess.run([VINA, '--config', cfg], capture_output=True, text=True,
                       cwd=BASE, timeout=900)
    open(log, 'w').write(r.stdout[-3000:] if r.stdout else '')
    if not os.path.exists(out_pdbqt) or os.path.getsize(out_pdbqt) < 500:
        return label, 'FAIL', None
    return label, 'OK', parse_affinity(out_pdbqt, log), round(time.time()-t0, 1)

results = {}
with ThreadPoolExecutor(max_workers=6) as ex:
    futs = {ex.submit(run_job, j): j[0] for j in jobs}
    done = 0
    for fut in as_completed(futs):
        res = fut.result()
        done += 1
        if res[1] == 'OK':
            results[res[0]] = res[2]
            print(f"[{done}/{len(jobs)}] {res[0]}: {res[2]:.2f} kcal/mol ({res[3]}s)", flush=True)
        else:
            print(f"[{done}/{len(jobs)}] {res[0]}: {res[1]}", flush=True)

json.dump(results, open(os.path.join(OUT, 'docking_results.json'), 'w'), indent=2)
print('DONE. Completed:', len(results), '/', len(jobs))