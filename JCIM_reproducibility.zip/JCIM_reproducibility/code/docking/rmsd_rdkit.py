# -*- coding: utf-8 -*-
"""Proper RMSD via RDKit substructure alignment between crystal BAT and docked pose."""
import os, sys
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'D:\投稿相关\CD_MDD\EJPS_submission\Revision\docking_extension'
WORK = r'C:\Users\ROG\AppData\Local\Temp\opencode'
LIG = os.path.join(BASE, 'ligands')
OUT = os.path.join(BASE, 'outputs')
import shutil

def rdkit_safe(src, name):
    dst = os.path.join(WORK, name)
    shutil.copy(src, dst)
    return dst

def read_pdbqt_models(path):
    models = []
    cur = []
    for l in open(path, encoding='utf-8', errors='replace'):
        if l.startswith('MODEL'):
            cur = []
        elif l.startswith('ENDMDL'):
            if cur:
                models.append(cur)
        elif l.startswith(('ATOM', 'HETATM')):
            cur.append(l.rstrip('\n'))
    return models

OBABEL = r'C:\Python312\Lib\site-packages\openbabel\bin\obabel.exe'
import subprocess

def model_0_as_sdf(src_pdbqt):
    models = read_pdbqt_models(src_pdbqt)
    if not models:
        return None
    tmp = os.path.join(WORK, 'pose_tmp.pdbqt')
    with open(tmp, 'w') as f:
        f.write('\n'.join(models[0]) + '\nEND\n')
    out_sdf = os.path.join(WORK, 'pose_out.sdf')
    r = subprocess.run([OBABEL, tmp, '-O', out_sdf], capture_output=True, text=True)
    if not os.path.exists(out_sdf):
        return None
    return Chem.SDMolSupplier(out_sdf, removeHs=True, sanitize=True)[0]

# crystal
cryst_mol = Chem.MolFromPDBFile(rdkit_safe(os.path.join(LIG, 'BAT_crystal.pdb'), 'BAT_crystal_safe.pdb'), removeHs=True, sanitize=True)
print('Crystal mol:', cryst_mol.GetNumAtoms() if cryst_mol else None, 'atoms')

for label in ['REDOCK_1MMB__BAT', 'REDOCK_1MMB__BAT_x32']:
    models = read_pdbqt_models(os.path.join(OUT, f'{label}_out.pdbqt'))
    if not models:
        print(label, ': no models')
        continue
    # use best (first) model
    dock_mol = model_0_as_sdf(os.path.join(OUT, f'{label}_out.pdbqt'))
    if dock_mol is None:
        print(label, ': failed to parse docked pose')
        continue
    # raw RMSD same frame (substructure match then compare)
    rms_raw = AllChem.GetBestRMS(cryst_mol, dock_mol)  # aligns then computes RMSD
    # alignment RMSD
    rms_align = AllChem.GetBestRMS(cryst_mol, dock_mol)
    print(f'{label}: docked atoms={dock_mol.GetNumAtoms()}, RMSD (best substructure match, aligned) = {rms_align:.3f} A')